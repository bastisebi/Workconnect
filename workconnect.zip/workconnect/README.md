# WorkConnect

Mobile-first Web-App für Handwerk & Außendienst (Aufträge, Kalender, Stempeluhr, Chat, Reklamationen).

Kein Build, kein npm. Dateien ins GitHub-Repo legen und `index.html` öffnen – oder über GitHub Pages hosten.

## Start

1. Dieses Verzeichnis als Repo nutzen (oder Dateien hochladen).
2. `index.html` im Browser öffnen **oder** lokal einen Mini-Server starten:

```bash
# Python
python3 -m http.server 8080

# Node
npx serve .
```

3. Auf dem Handy: gleiche URL im WLAN, oder als Lesezeichen / zum Home-Bildschirm.

Daten liegen im Browser (`localStorage`). Jeder Browser / jedes Gerät hat zunächst eigene Demo-Daten.

## Demo-Zugang

| Rolle | Name | Anmelden als |
|---|---|---|
| Admin | Max Müller | Admin |
| Verkäuferin | Anna Schneider | Verkäufer |
| Monteur | Thomas Weber | Monteur |

Kein Passwort in der Demo. Rollen steuern sichtbare Menüs und Aktionen.

## Was bereits funktioniert

- Anmeldung mit Rolle
- Startseite inkl. Anpassen (Reihenfolge, ein-/ausblenden, Standard wiederherstellen)
- Kalender: Tag / Woche / Monat, Termine anlegen, löschen
- Aufträge: Filter, Status ändern, neuen Auftrag anlegen, PDF-Ansicht
- Stempeluhr: Ein-/Ausstempeln, Wochenübersicht, Standortprüfung (Browser-GPS)
- Stempelorte (Admin): Firma, Lager, Baustelle mit Radius
- Reklamationen: Status und Priorität
- Chat: Unterhaltungen, Nachrichten senden (lokal)
- Kontakte: Suche + Filter Mitarbeiter / Kunden / Lieferanten
- Arbeitszeiten (Admin)
- Einstellungen inkl. Rollenhinweis
- Deutsche Oberfläche, dunkles Theme wie im Mockup

## Rechte (aktueller Stand)

- **Admin:** alles inkl. Kalender, Arbeitszeiten, Stempelorte und Aufmaß-App
- **Verkäufer:** Kalender, Aufträge, Kontakte, Chat, Reklamationen, Stempeluhr, Aufmaß-App
- **Monteur:** eigene Stempeluhr, zugewiesene Aufträge, Kalender, Chat, Reklamationen (kein Aufmaß)

Die Rechte kannst du später in `app.js` (`PERMISSIONS`) feiner justieren.

## GitHub Pages

Settings → Pages → Deploy from branch → `/` (root).  
Danach ist die App unter `https://<user>.github.io/<repo>/` erreichbar.

## Nächste sinnvolle Schritte (Backend)

Aktuell ist alles clientseitig. Für echte Teams brauchst du später:

- Login mit Passwort / SSO
- Gemeinsame Datenbank (z. B. Supabase oder Firebase)
- Push-Benachrichtigungen
- Datei-Upload zu Aufträgen
- Echte Karten-API

Die UI und die Logik sind so geschnitten, dass sich das austauschen lässt.
