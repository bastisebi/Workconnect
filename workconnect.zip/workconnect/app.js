const PERMISSIONS = {
  admin: ["start","kalender","auftraege","chat","kontakte","reklamationen","stempeluhr","einstellungen","arbeitszeiten","stempelorte","customize","alle-auftraege","aufmass"],
  verkaeufer: ["start","kalender","auftraege","chat","kontakte","reklamationen","stempeluhr","einstellungen","customize","alle-auftraege","aufmass"],
  monteur: ["start","kalender","auftraege","chat","kontakte","reklamationen","stempeluhr","einstellungen"]
};

const USERS = {
  admin: { id: "u1", name: "Max Müller", role: "admin", job: "Inhaber", phone: "+49 170 1234567", initials: "MM", color: "#2563eb" },
  verkaeufer: { id: "u2", name: "Anna Schneider", role: "verkaeufer", job: "Verkäuferin", phone: "+49 172 9876543", initials: "AS", color: "#db2777" },
  monteur: { id: "u3", name: "Thomas Weber", role: "monteur", job: "Monteur", phone: "+49 171 4567890", initials: "TW", color: "#0d9488" }
};

const DEFAULT_MODULES = [
  { id: "chat", title: "Chat", icon: "chat" },
  { id: "kontakte", title: "Kontakte", icon: "people" },
  { id: "kalender", title: "Kalender", icon: "cal" },
  { id: "auftraege", title: "Aufträge", icon: "box" },
  { id: "reklamationen", title: "Reklamationen", icon: "alert" },
  { id: "stempeluhr", title: "Stempeluhr", icon: "clock" },
  { id: "aufmass", title: "Aufmaß", icon: "ruler" }
];

const EXTRA_MODULES = [
  { id: "arbeitszeiten", title: "Arbeitszeiten", icon: "chart" },
  { id: "fertigstellungen", title: "Fertigstellungen", icon: "check" },
  { id: "einstellungen", title: "Einstellungen", icon: "gear" }
];

function seed() {
  return {
    contacts: [
      { id: "u1", name: "Max Müller", role: "Mitarbeiter", job: "Inhaber", phone: "+49 170 1234567", initials: "MM", color: "#2563eb" },
      { id: "u2", name: "Anna Schneider", role: "Mitarbeiter", job: "Verkäuferin", phone: "+49 172 9876543", initials: "AS", color: "#db2777" },
      { id: "u3", name: "Thomas Weber", role: "Mitarbeiter", job: "Monteur", phone: "+49 171 4567890", initials: "TW", color: "#0d9488" },
      { id: "u4", name: "Lisa Wagner", role: "Mitarbeiter", job: "Monteurin", phone: "+49 173 1122334", initials: "LW", color: "#7c3aed" },
      { id: "c1", name: "Firma Baustoffe Huber", role: "Lieferant", job: "Büro", phone: "+49 8821 998877", initials: "FB", color: "#334155" },
      { id: "c2", name: "Küchenstudio Mayer", role: "Kunde", job: "Kunde", phone: "+49 8821 665544", initials: "KM", color: "#0f766e" },
      { id: "c3", name: "Familie Berger", role: "Kunde", job: "Kunde", phone: "+49 170 5556677", initials: "FB", color: "#b45309" }
    ],
    orders: [
      { id: 1042, customer: "Max Mustermann", address: "Musterstraße 12, 82467 Garmisch-Partenkirchen", date: "2026-09-04", from: "10:00", to: "12:00", assignee: "Max Müller", status: "Offen", desc: "Wasserhahn tropft." },
      { id: 1045, customer: "Anna Schneider", address: "Hauptstraße 8, 82467 Garmisch-Partenkirchen", date: "2026-09-04", from: "14:30", to: "16:00", assignee: "Thomas Weber", status: "In Arbeit", desc: "Küchenarmatur tauschen." },
      { id: 1048, customer: "Thomas Berger", address: "Am Kurpark 3, 82467 Garmisch-Partenkirchen", date: "2026-09-05", from: "09:00", to: "11:00", assignee: "Max Müller", status: "Offen", desc: "Kühlschrank kühlt nicht richtig." },
      { id: 1050, customer: "Lisa Wagner", address: "Bahnhofstr. 2", date: "2026-09-05", from: "13:00", to: "15:00", assignee: "Thomas Weber", status: "In Arbeit", desc: "Turdichtung prüfen." }
    ],
    complaints: [
      { id: 1042, customer: "Max Mustermann", date: "2026-09-04", ref: 1042, status: "Offen", prio: "Dringend", desc: "Wasserhahn tropft." },
      { id: 1048, customer: "Thomas Berger", date: "2026-09-05", ref: 1048, status: "In Bearbeitung", prio: "Normal", desc: "Kühlschrank kühlt nicht richtig." },
      { id: 1050, customer: "Lisa Wagner", date: "2026-09-05", ref: 1050, status: "Abgeschlossen", prio: "Normal", desc: "Turdichtung erneuert." }
    ],
    events: [
      { id: "e1", date: "2026-09-04", from: "10:00", to: "12:00", title: "#1042 · Max Mustermann", sub: "Musterstraße 12, 82467 Garmisch-Partenkirchen", color: "blue" },
      { id: "e2", date: "2026-09-04", from: "12:00", to: "13:00", title: "Mittagspause", sub: "", color: "gray" },
      { id: "e3", date: "2026-09-04", from: "14:30", to: "16:00", title: "#1045 · Anna Schneider", sub: "Hauptstraße 8, 82467 Garmisch-Partenkirchen", color: "green" }
    ],
    chats: [
      { id: "ch1", name: "Max Müller", preview: "Hey, bist du heute noch in der Firma?", time: "09:28", unread: 1, kind: "Mitarbeiter" },
      { id: "ch2", name: "Team Allgemein", preview: "Lisa: Alles klar", time: "08:45", unread: 2, kind: "Mitarbeiter" },
      { id: "ch3", name: "Anna Schneider", preview: "Danke für die Info!", time: "Gestern", unread: 0, kind: "Mitarbeiter" },
      { id: "ch4", name: "Kunde · Familie Berger", preview: "Termin bestätigt.", time: "Gestern", unread: 0, kind: "Kunde" },
      { id: "ch5", name: "Thomas Weber", preview: "Schick mir bitte die Bilder.", time: "Gestern", unread: 0, kind: "Mitarbeiter" },
      { id: "ch6", name: "Kundendienst", preview: "Neuer Auftrag #1048", time: "Gestern", unread: 0, kind: "Kunde" }
    ],
    messages: {
      ch1: [
        { me: false, text: "Hey, bist du heute noch in der Firma?" },
        { me: true, text: "Ja, bis ca. 17 Uhr." }
      ],
      ch2: [{ me: false, text: "Lisa: Alles klar" }]
    },
    locations: [
      { id: "l1", name: "Firma", radius: 100, active: true, lat: 47.492, lng: 11.096 },
      { id: "l2", name: "Lager", radius: 150, active: true, lat: 47.495, lng: 11.090 },
      { id: "l3", name: "Baustelle München", radius: 200, active: true, lat: 48.137, lng: 11.576 }
    ],
    punches: [],
    punchedIn: false,
    punchStart: null,
    homeOrder: DEFAULT_MODULES.map(m => m.id),
    homeHidden: [],
    weekHours: { soll: 40 * 60, ist: 40 * 60 + 28 },
    measures: [
      {
        id: "m1",
        name: "Max Mustermann",
        address: "Musterstraße 12, 82467 Garmisch-Partenkirchen",
        phone: "+49 170 1112233",
        email: "mustermann@example.de",
        created: "2026-09-04",
        photos: []
      }
    ]
  };
}

const STORE_KEY = "workconnect.v1";
let db = load();
let session = JSON.parse(localStorage.getItem("workconnect.session") || "null");
let ui = {
  screen: "start",
  calMode: "tag",
  calDate: new Date(2026, 8, 4),
  orderFilter: "Alle",
  contactFilter: "Alle",
  chatFilter: "Alle",
  complaintFilter: "Offen",
  activeChat: null,
  pdfOrder: null,
  measureId: null,
  photoIndex: 0,
  drawMode: "arrow",
  draftLine: null,
  pendingArrow: null
};

const NOTE_CHOICES = [
  "Wasseranschluss",
  "Stromanschluss",
  "Abfluss",
  "Höhe prüfen",
  "Breite prüfen",
  "Beschädigt",
  "Kundenwunsch",
  "Vor Ort klären",
  "Maß vom Kunden",
  "Passung unsicher",
  "Foto nur zur Dokumentation"
];

function load() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return seed();
    return { ...seed(), ...JSON.parse(raw) };
  } catch {
    return seed();
  }
}
function save() {
  localStorage.setItem(STORE_KEY, JSON.stringify(db));
}
function saveSession() {
  localStorage.setItem("workconnect.session", JSON.stringify(session));
}

function can(feature) {
  if (!session) return false;
  return (PERMISSIONS[session.role] || []).includes(feature);
}

function $(id) { return document.getElementById(id); }
function showScreen(name) {
  if (name === "arbeitszeiten" && !can("arbeitszeiten")) name = "start";
  if (name === "stempeluhr" && !can("stempeluhr")) name = "start";
  if ((name === "aufmass" || name === "aufmass-edit") && !can("aufmass")) name = "start";
  ui.screen = name;
  document.querySelectorAll(".screen").forEach(s => s.classList.toggle("active", s.dataset.screen === name));
  document.querySelectorAll(".nav button").forEach(b => b.classList.toggle("on", b.dataset.go === name || (name !== "start" && name !== "kalender" && name !== "auftraege" && b.dataset.go === "mehr" && ["chat","kontakte","reklamationen","stempeluhr","einstellungen","customize","arbeitszeiten","stempelorte","pdf","success"].includes(name))));
  if (name === "start") renderHome();
  if (name === "kalender") renderCalendar();
  if (name === "auftraege") renderOrders();
  if (name === "chat") renderChats();
  if (name === "kontakte") renderContacts();
  if (name === "reklamationen") renderComplaints();
  if (name === "stempeluhr") renderClock();
  if (name === "einstellungen") renderSettings();
  if (name === "customize") renderCustomize();
  if (name === "arbeitszeiten") renderHours();
  if (name === "stempelorte") renderLocations();
  if (name === "mehr") renderMore();
  if (name === "thread") renderThread();
  if (name === "pdf") renderPdf();
  if (name === "aufmass") renderMeasures();
  if (name === "aufmass-edit") renderMeasureEdit();
}

function icon(name, color) {
  const map = {
    chat: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/></svg>`,
    people: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>`,
    cal: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>`,
    box: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 8l-9-4-9 4 9 4 9-4z"/><path d="M3 8v8l9 4 9-4V8"/></svg>`,
    alert: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/></svg>`,
    clock: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>`,
    chart: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 20V10M12 20V4M20 20v-7"/></svg>`,
    check: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg>`,
    gear: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9c.3.6.9 1 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>`,
    ruler: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 8h18v8H3z"/><path d="M7 8v3M11 8v4M15 8v3M19 8v4"/></svg>`
  };
  const bg = { chat:"#16a34a", people:"#2563eb", cal:"#7c3aed", box:"#f59e0b", alert:"#ef4444", clock:"#14b8a6", chart:"#64748b", check:"#22c55e", gear:"#64748b", ruler:"#06b6d4" };
  return `<div class="mod-icon" style="background:${bg[name]||"#334155"}22;color:${bg[name]||"#93c5fd"}">${map[name]||""}</div>`;
}

function fmtDate(d) {
  return d.toLocaleDateString("de-DE", { weekday: "long", day: "2-digit", month: "2-digit", year: "numeric" });
}
function iso(d) {
  const z = n => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())}`;
}
function minutesNow() {
  const n = new Date();
  return n.getHours() * 60 + n.getMinutes();
}
function hm(mins) {
  const h = Math.floor(Math.abs(mins) / 60);
  const m = Math.abs(mins) % 60;
  return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`;
}

function visibleOrders() {
  if (can("alle-auftraege")) return db.orders;
  return db.orders.filter(o => o.assignee === session.name);
}

function renderHome() {
  $("hello-name").textContent = `Hallo ${session.name}`;
  const openOrders = visibleOrders().filter(o => o.status !== "Abgeschlossen").length;
  const openComp = db.complaints.filter(c => c.status !== "Abgeschlossen").length;
  const todayEvents = db.events.filter(e => e.date === iso(new Date()) || e.date === iso(ui.calDate)).length;
  const unread = db.chats.reduce((a,c) => a + (c.unread||0), 0);
  const staff = db.contacts.filter(c => c.role === "Mitarbeiter").length;
  const meta = {
    chat: unread ? `${unread} neue Nachrichten` : "Keine neuen Nachrichten",
    kontakte: `${staff} Mitarbeiter`,
    kalender: `${Math.max(todayEvents, db.events.filter(e=>e.date===iso(ui.calDate)).length)} Termine`,
    auftraege: `${openOrders} offene Aufträge`,
    reklamationen: `${openComp} offen`,
    stempeluhr: db.punchedIn ? "Gestempelt" : "Nicht gestempelt",
    aufmass: `${(db.measures||[]).length} Projekte`
  };
  const order = db.homeOrder.length ? db.homeOrder : DEFAULT_MODULES.map(m => m.id);
  const mods = order
    .map(id => DEFAULT_MODULES.find(m => m.id === id))
    .filter(Boolean)
    .filter(m => !db.homeHidden.includes(m.id))
    .filter(m => m.id !== "stempeluhr" || can("stempeluhr"))
    .filter(m => m.id !== "aufmass" || can("aufmass"));
  $("home-list").innerHTML = mods.map(m => `
    <button class="row" onclick="showScreen('${m.id}')">
      ${icon(m.icon)}
      <div class="grow"><div class="title">${m.title}</div><div class="sub">${meta[m.id]||""}</div></div>
      ${m.id==="chat" && unread ? `<span class="badge">${unread}</span>` : `<span class="chev">›</span>`}
    </button>
  `).join("");
}

function renderMore() {
  const items = [
    can("chat") && ["chat","Chat"],
    can("kontakte") && ["kontakte","Kontakte"],
    can("reklamationen") && ["reklamationen","Reklamationen"],
    can("stempeluhr") && ["stempeluhr","Stempeluhr"],
    can("aufmass") && ["aufmass","Aufmaß"],
    can("arbeitszeiten") && ["arbeitszeiten","Arbeitszeiten (Admin)"],
    can("stempelorte") && ["stempelorte","Stempelorte (Admin)"],
    ["einstellungen","Einstellungen"]
  ].filter(Boolean);
  $("more-list").innerHTML = items.map(([id,label]) => `
    <button class="row" onclick="showScreen('${id}')"><div class="grow"><div class="title">${label}</div></div><span class="chev">›</span></button>
  `).join("");
}

function renderCustomize() {
  const all = [...DEFAULT_MODULES, ...EXTRA_MODULES.filter(m => m.id !== "arbeitszeiten" || can("arbeitszeiten"))];
  $("custom-list").innerHTML = all.map(m => {
    const hidden = db.homeHidden.includes(m.id);
    return `<div class="row" draggable="true" data-id="${m.id}">
      <span class="drag-handle">⠿</span>
      ${icon(m.icon)}
      <div class="grow"><div class="title">${m.title}</div></div>
      <button class="hide-toggle" onclick="toggleModule('${m.id}')">${hidden ? "○" : "◉"}</button>
    </div>`;
  }).join("");
}

function toggleModule(id) {
  if (db.homeHidden.includes(id)) db.homeHidden = db.homeHidden.filter(x => x !== id);
  else db.homeHidden.push(id);
  save(); renderCustomize();
}
function resetHome() {
  db.homeOrder = DEFAULT_MODULES.map(m => m.id);
  db.homeHidden = [];
  save(); renderCustomize();
}
function saveHome() {
  showScreen("success");
}

function renderCalendar() {
  const d = ui.calDate;
  $("cal-title").textContent = fmtDate(d);
  document.querySelectorAll("[data-calmode]").forEach(b => b.classList.toggle("on", b.dataset.calmode === ui.calMode));
  if (ui.calMode === "tag") {
    const hours = [];
    for (let h = 8; h <= 17; h++) hours.push(h);
    const dayIso = iso(d);
    const evs = db.events.filter(e => e.date === dayIso);
    $("cal-body").innerHTML = `<div class="hours">${hours.map(h => {
      const label = String(h).padStart(2,"0") + ":00";
      const at = evs.filter(e => parseInt(e.from,10) === h || (parseInt(e.from,10) < h && parseInt(e.to,10) > h && parseInt(e.from,10) !== h));
      const startHere = evs.filter(e => parseInt(e.from,10) === h);
      return `<div class="hour" data-h="${label}">${startHere.map(e => `
        <div class="event ${e.color}" onclick="deleteEvent('${e.id}')">
          <b>${e.title}</b><div class="tiny">${e.from} – ${e.to}${e.sub ? " · " + e.sub : ""}</div>
        </div>`).join("")}</div>`;
    }).join("")}</div>`;
  } else if (ui.calMode === "woche") {
    const start = new Date(d); start.setDate(d.getDate() - ((d.getDay()+6)%7));
    const days = [...Array(7)].map((_,i) => { const x = new Date(start); x.setDate(start.getDate()+i); return x; });
    $("cal-body").innerHTML = days.map(day => {
      const evs = db.events.filter(e => e.date === iso(day));
      return `<div class="card"><b>${day.toLocaleDateString("de-DE",{weekday:"short",day:"2-digit",month:"2-digit"})}</b>
        ${evs.length ? evs.map(e => `<div class="tiny" style="margin-top:6px">${e.from} ${e.title}</div>`).join("") : `<div class="tiny" style="margin-top:6px">Keine Termine</div>`}
      </div>`;
    }).join("");
  } else {
    const y = d.getFullYear(), m = d.getMonth();
    const first = new Date(y,m,1);
    const startOff = (first.getDay()+6)%7;
    const daysIn = new Date(y,m+1,0).getDate();
    let html = `<div class="month-grid">${["Mo","Di","Mi","Do","Fr","Sa","So"].map(x=>`<div class="wd">${x}</div>`).join("")}`;
    for (let i=0;i<startOff;i++) html += `<div></div>`;
    for (let day=1; day<=daysIn; day++) {
      const dt = new Date(y,m,day);
      const has = db.events.some(e => e.date === iso(dt));
      const today = iso(dt) === iso(d);
      html += `<button class="d${has?" has":""}${today?" today":""}" onclick="pickDay(${y},${m},${day})">${day}</button>`;
    }
    html += `</div>`;
    $("cal-body").innerHTML = html;
  }
}
function pickDay(y,m,day) {
  ui.calDate = new Date(y,m,day);
  ui.calMode = "tag";
  renderCalendar();
}
function shiftCal(dir) {
  const d = new Date(ui.calDate);
  if (ui.calMode === "monat") d.setMonth(d.getMonth()+dir);
  else d.setDate(d.getDate()+dir);
  ui.calDate = d;
  renderCalendar();
}
function setCalMode(mode) { ui.calMode = mode; renderCalendar(); }

function openEventModal() {
  $("ev-date").value = iso(ui.calDate);
  $("ev-from").value = "09:00";
  $("ev-to").value = "10:00";
  $("ev-title").value = "";
  $("ev-sub").value = "";
  $("modal-event").classList.add("show");
}
function saveEvent() {
  db.events.push({
    id: "e" + Date.now(),
    date: $("ev-date").value,
    from: $("ev-from").value,
    to: $("ev-to").value,
    title: $("ev-title").value || "Termin",
    sub: $("ev-sub").value,
    color: "blue"
  });
  save();
  closeModal("modal-event");
  renderCalendar();
}
function deleteEvent(id) {
  if (!confirm("Termin löschen?")) return;
  db.events = db.events.filter(e => e.id !== id);
  save(); renderCalendar();
}

function renderOrders() {
  const f = ui.orderFilter;
  let list = visibleOrders();
  if (f === "Offen") list = list.filter(o => o.status === "Offen");
  if (f === "In Arbeit") list = list.filter(o => o.status === "In Arbeit");
  if (f === "Abgeschlossen") list = list.filter(o => o.status === "Abgeschlossen");
  const q = ($("order-q")?.value || "").toLowerCase();
  if (q) list = list.filter(o => `${o.id} ${o.customer} ${o.address}`.toLowerCase().includes(q));
  $("order-counts").innerHTML = `
    ${chip("orderFilter","Alle", `Alle`)}
    ${chip("orderFilter","Offen", `Offen (${visibleOrders().filter(o=>o.status==="Offen").length})`)}
    ${chip("orderFilter","In Arbeit", `In Arbeit (${visibleOrders().filter(o=>o.status==="In Arbeit").length})`)}
    ${chip("orderFilter","Abgeschlossen", "Abgeschlossen")}
  `;
  $("order-list").innerHTML = list.map(o => `
    <div class="row" style="align-items:flex-start">
      <div class="grow" onclick="openPdf(${o.id})">
        <div class="title">#${o.id} · ${o.customer}</div>
        <div class="sub">${o.date} · ${o.from} – ${o.to}<br>${o.address}<br>${o.assignee}</div>
      </div>
      <button class="status ${o.status==="Offen"?"st-offen":o.status==="In Arbeit"?"st-arbeit":"st-fertig"}" onclick="cycleOrder(${o.id})">${o.status}</button>
    </div>
  `).join("") || `<div class="card muted">Keine Aufträge</div>`;
}
function chip(group, value, label) {
  const on = ui[group] === value ? "on" : "";
  return `<button class="chip ${on}" onclick="setFilter('${group}','${value}')">${label}</button>`;
}
function setFilter(group, value) {
  ui[group] = value;
  if (group === "orderFilter") renderOrders();
  if (group === "contactFilter") renderContacts();
  if (group === "chatFilter") renderChats();
  if (group === "complaintFilter") renderComplaints();
}
function cycleOrder(id) {
  const o = db.orders.find(x => x.id === id);
  if (!o) return;
  o.status = o.status === "Offen" ? "In Arbeit" : o.status === "In Arbeit" ? "Abgeschlossen" : "Offen";
  save(); renderOrders();
}
function openOrderModal() {
  $("or-id").value = String(Math.max(...db.orders.map(o=>o.id)) + 1);
  $("or-cust").value = "";
  $("or-addr").value = "";
  $("or-date").value = iso(ui.calDate);
  $("or-from").value = "09:00";
  $("or-to").value = "11:00";
  $("or-asg").value = session.name;
  $("or-desc").value = "";
  $("modal-order").classList.add("show");
}
function saveOrder() {
  const id = parseInt($("or-id").value,10);
  const order = {
    id, customer: $("or-cust").value || "Kunde",
    address: $("or-addr").value || "",
    date: $("or-date").value, from: $("or-from").value, to: $("or-to").value,
    assignee: $("or-asg").value, status: "Offen", desc: $("or-desc").value
  };
  db.orders.push(order);
  db.events.push({
    id: "e"+Date.now(), date: order.date, from: order.from, to: order.to,
    title: `#${id} · ${order.customer}`, sub: order.address, color: "blue"
  });
  save(); closeModal("modal-order"); renderOrders();
}
function openPdf(id) {
  ui.pdfOrder = db.orders.find(o => o.id === id);
  showScreen("pdf");
}
function renderPdf() {
  const o = ui.pdfOrder;
  if (!o) { $("pdf-box").innerHTML = "Kein Auftrag"; return; }
  $("pdf-box").innerHTML = `
    <div class="pdf">
      <h3>Auftrag #${o.id}</h3>
      <p><b>Kunde</b><br>${o.customer}<br>${o.address}</p>
      <p style="margin-top:10px"><b>Termin</b><br>${o.date} · ${o.from} – ${o.to}<br>Monteur: ${o.assignee}</p>
      <p style="margin-top:10px"><b>Beschreibung</b><br>${o.desc || "—"}</p>
      <p style="margin-top:10px"><b>Status</b><br>${o.status}</p>
    </div>`;
}

function renderContacts() {
  const f = ui.contactFilter;
  let list = db.contacts;
  if (f !== "Alle") list = list.filter(c => c.role === f || (f==="Lieferanten" && c.role==="Lieferant") || (f==="Kunden" && c.role==="Kunde") || (f==="Mitarbeiter" && c.role==="Mitarbeiter"));
  const q = ($("contact-q")?.value || "").toLowerCase();
  if (q) list = list.filter(c => `${c.name} ${c.job} ${c.phone}`.toLowerCase().includes(q));
  $("contact-chips").innerHTML = ["Alle","Mitarbeiter","Kunden","Lieferanten"].map(x => chip("contactFilter", x, x)).join("");
  $("contact-list").innerHTML = list.map(c => `
    <div class="row">
      <div class="ava" style="background:${c.color}33;color:${c.color}">${c.initials}</div>
      <div class="grow"><div class="title">${c.name}</div><div class="sub">${c.job}<br>${c.phone}</div></div>
      <a class="icon-btn" href="tel:${c.phone.replace(/\s/g,"")}">📞</a>
    </div>
  `).join("");
}

function renderChats() {
  const f = ui.chatFilter;
  let list = db.chats;
  if (f === "Alle Kunden") list = list.filter(c => c.kind === "Kunde");
  if (f === "Alle Mitarbeiter") list = list.filter(c => c.kind === "Mitarbeiter");
  const q = ($("chat-q")?.value || "").toLowerCase();
  if (q) list = list.filter(c => c.name.toLowerCase().includes(q));
  $("chat-chips").innerHTML = ["Alle","Alle Kunden","Alle Mitarbeiter"].map(x => chip("chatFilter", x, x)).join("");
  $("chat-list").innerHTML = list.map(c => `
    <button class="row" onclick="openChat('${c.id}')">
      <div class="ava" style="background:#1d4ed833;color:#93c5fd">${c.name.slice(0,2).toUpperCase()}</div>
      <div class="grow"><div class="title">${c.name}</div><div class="sub">${c.preview}</div></div>
      <div style="text-align:right"><div class="tiny">${c.time}</div>${c.unread?`<span class="badge">${c.unread}</span>`:""}</div>
    </button>
  `).join("");
}
function openChat(id) {
  ui.activeChat = id;
  const ch = db.chats.find(c => c.id === id);
  if (ch) ch.unread = 0;
  save();
  showScreen("thread");
}
function renderThread() {
  const ch = db.chats.find(c => c.id === ui.activeChat);
  $("thread-title").textContent = ch ? ch.name : "Chat";
  const msgs = db.messages[ui.activeChat] || [];
  $("thread-list").innerHTML = msgs.map(m => `<div class="${m.me?"bubble-me":"bubble-them"}">${escapeHtml(m.text)}</div>`).join("") || `<div class="card muted">Noch keine Nachrichten</div>`;
}
function sendMsg() {
  const t = $("msg-input").value.trim();
  if (!t || !ui.activeChat) return;
  db.messages[ui.activeChat] = db.messages[ui.activeChat] || [];
  db.messages[ui.activeChat].push({ me: true, text: t });
  const ch = db.chats.find(c => c.id === ui.activeChat);
  if (ch) { ch.preview = t; ch.time = "Jetzt"; }
  $("msg-input").value = "";
  save(); renderThread();
}

function renderComplaints() {
  const f = ui.complaintFilter;
  let list = db.complaints;
  if (f !== "Alle") list = list.filter(c => c.status === f || (f==="Offen" && c.status==="Offen"));
  $("comp-chips").innerHTML = [
    ["Offen", `Offen (${db.complaints.filter(c=>c.status==="Offen").length})`],
    ["In Bearbeitung", "In Bearbeitung"],
    ["Abgeschlossen", "Abgeschlossen"]
  ].map(([v,l]) => chip("complaintFilter", v, l)).join("");
  $("comp-list").innerHTML = list.map(c => `
    <div class="row" style="align-items:flex-start">
      <div class="grow">
        <div class="title">#${c.id} · ${c.customer}</div>
        <div class="sub">${c.date} · Auftrag #${c.ref}<br>Beschreibung: ${c.desc}</div>
      </div>
      <button class="status ${c.status==="Offen"?"st-dringend":c.status==="In Bearbeitung"?"st-bearbeitung":"st-ok"}" onclick="cycleComp(${c.id})">${c.status==="Offen" && c.prio==="Dringend" ? "Dringend" : c.status}</button>
    </div>
  `).join("");
}
function cycleComp(id) {
  const c = db.complaints.find(x => x.id === id);
  if (!c) return;
  c.status = c.status === "Offen" ? "In Bearbeitung" : c.status === "In Bearbeitung" ? "Abgeschlossen" : "Offen";
  save(); renderComplaints();
}

function haversine(a,b) {
  const R = 6371000;
  const toRad = x => x * Math.PI / 180;
  const dLat = toRad(b.lat-a.lat), dLng = toRad(b.lng-a.lng);
  const s = Math.sin(dLat/2)**2 + Math.cos(toRad(a.lat))*Math.cos(toRad(b.lat))*Math.sin(dLng/2)**2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

function renderClock() {
  const elapsed = db.punchedIn && db.punchStart ? Math.max(0, Date.now() - db.punchStart) : 0;
  const mins = Math.floor(elapsed / 60000);
  $("clock-time").textContent = hm(mins || minutesNow());
  $("clock-label").textContent = db.punchedIn ? "Arbeitszeit" : "Nicht gestempelt";
  $("punch-btn").textContent = db.punchedIn ? "✓  AUSSTEMPELN" : "✓  EINSTEMPELN";
  $("punch-btn").classList.toggle("out", db.punchedIn);
  const today = iso(new Date());
  const todayPunches = db.punches.filter(p => p.day === today && p.user === session.name);
  const worked = todayPunches.reduce((a,p) => a + (p.minutes||0), 0) + (db.punchedIn ? mins : 0);
  $("today-hours").textContent = hm(worked) + " Std.";
  const week = { Mo:0,Di:0,Mi:0,Do:0,Fr:0,Sa:0,So:0 };
  db.punches.filter(p => p.user === session.name).forEach(p => {
    const dt = new Date(p.day + "T12:00:00");
    const key = ["So","Mo","Di","Mi","Do","Fr","Sa"][dt.getDay()];
    if (week[key] !== undefined) week[key] += p.minutes;
  });
  if (db.punchedIn) {
    const key = ["So","Mo","Di","Mi","Do","Fr","Sa"][new Date().getDay()];
    week[key] += mins;
  }
  $("week-hours").innerHTML = Object.entries(week).slice(0,7).map(([k,v]) => `<div>${k} ${hm(v)} Std.</div>`).join("");
  $("loc-status").textContent = "Standort wird geprüft…";
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(pos => {
      const here = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      let best = null, bestD = Infinity;
      db.locations.filter(l => l.active).forEach(l => {
        const d = haversine(here, l);
        if (d < bestD) { bestD = d; best = l; }
      });
      if (best) {
        const ok = bestD <= best.radius;
        $("loc-status").innerHTML = `<b>${best.name}</b><div class="tiny">${Math.round(bestD)} m entfernt ${ok ? "· im Radius" : "· außerhalb"}</div>`;
        $("punch-btn").disabled = false;
        $("punch-btn").dataset.ok = ok ? "1" : "0";
        $("punch-btn").dataset.place = best.name;
      } else {
        $("loc-status").textContent = "Kein Stempelort hinterlegt";
      }
    }, () => {
      $("loc-status").innerHTML = `<b>Firma</b><div class="tiny">GPS nicht erlaubt – Demo-Modus (12 m)</div>`;
      $("punch-btn").dataset.ok = "1";
      $("punch-btn").dataset.place = "Firma";
    }, { enableHighAccuracy: true, timeout: 4000 });
  } else {
    $("loc-status").innerHTML = `<b>Firma</b><div class="tiny">Kein GPS – Demo-Modus</div>`;
    $("punch-btn").dataset.ok = "1";
    $("punch-btn").dataset.place = "Firma";
  }
}

function togglePunch() {
  const ok = $("punch-btn").dataset.ok !== "0";
  if (!ok && !db.punchedIn) {
    alert("Du bist außerhalb eines erlaubten Stempelorts.");
    return;
  }
  if (!db.punchedIn) {
    db.punchedIn = true;
    db.punchStart = Date.now();
  } else {
    const mins = Math.max(1, Math.round((Date.now() - db.punchStart) / 60000));
    db.punches.push({
      user: session.name,
      day: iso(new Date()),
      minutes: mins,
      place: $("punch-btn").dataset.place || "Firma"
    });
    db.punchedIn = false;
    db.punchStart = null;
  }
  save();
  renderClock();
}

function renderHours() {
  const names = [...new Set(db.punches.map(p => p.user).concat([session.name]))];
  $("hours-user").innerHTML = names.map(n => `<option>${n}</option>`).join("");
  const user = $("hours-user").value || session.name;
  const ist = db.punches.filter(p => p.user === user).reduce((a,p)=>a+p.minutes,0);
  const soll = 40 * 60;
  $("hours-ist").textContent = hm(ist || db.weekHours.ist);
  $("hours-soll").textContent = hm(soll);
  const diff = (ist || db.weekHours.ist) - soll;
  $("hours-diff").textContent = (diff>=0?"+":"-") + hm(diff);
  $("hours-diff").style.color = diff >= 0 ? "#4ade80" : "#f87171";
  const week = { Mo: 8*60+12, Di: 7*60+54, Mi: 8*60+58, Do: 0, Fr: 0, Sa: 0, So: 0 };
  db.punches.filter(p => p.user === user).forEach(p => {
    const dt = new Date(p.day+"T12:00:00");
    const key = ["So","Mo","Di","Mi","Do","Fr","Sa"][dt.getDay()];
    if (week[key] != null) week[key] = (week[key] < 60 ? 0 : week[key]); 
  });
  $("hours-bars").innerHTML = Object.entries({Mo:week.Mo,Di:week.Di,Mi:week.Mi,Do:week.Do,Fr:week.Fr}).map(([k,v]) => `
    <div class="bar-row"><span>${k}</span><div class="bar"><i style="width:${Math.min(100, v/ (10*60) * 100)}%"></i></div><span>${hm(v)}</span></div>
  `).join("");
}

function renderLocations() {
  $("loc-list").innerHTML = db.locations.map(l => `
    <div class="row">
      <div class="grow"><div class="title">${l.name}</div><div class="sub">Radius ${l.radius} m · ${l.active?"Aktiv":"Inaktiv"}</div></div>
      <button class="chip ${l.active?"on":""}" onclick="toggleLoc('${l.id}')">${l.active?"Aktiv":"Aus"}</button>
    </div>
  `).join("");
}
function toggleLoc(id) {
  const l = db.locations.find(x => x.id === id);
  if (l) l.active = !l.active;
  save(); renderLocations();
}
function addLocation() {
  const name = prompt("Name des Stempelorts?");
  if (!name) return;
  db.locations.push({ id: "l"+Date.now(), name, radius: 100, active: true, lat: 47.49, lng: 11.09 });
  save(); renderLocations();
}

function currentMeasure() {
  return (db.measures || []).find(m => m.id === ui.measureId);
}
function renderMeasures() {
  const list = db.measures || [];
  $("measure-list").innerHTML = list.map(m => `
    <button class="row" onclick="openMeasure('${m.id}')">
      <div class="grow">
        <div class="title">${m.name || m.title || "Aufmaß"}</div>
        <div class="sub">${m.address || "Keine Adresse"} · ${(m.photos||[]).length} Fotos</div>
      </div>
      <span class="chev">›</span>
    </button>
  `).join("") || `<div class="card muted">Noch kein Aufmaß. Lege mit + ein Projekt an.</div>`;
}
function openMeasureModal() {
  $("ms-name").value = "";
  $("ms-address").value = "";
  $("ms-phone").value = "";
  $("ms-email").value = "";
  $("modal-measure").classList.add("show");
}
function saveMeasureProject() {
  const item = {
    id: "m" + Date.now(),
    name: $("ms-name").value || "Neues Aufmaß",
    address: $("ms-address").value,
    phone: $("ms-phone").value,
    email: $("ms-email").value,
    created: iso(new Date()),
    photos: []
  };
  db.measures = db.measures || [];
  db.measures.unshift(item);
  save();
  closeModal("modal-measure");
  openMeasure(item.id);
}
function openMeasure(id) {
  ui.measureId = id;
  ui.photoIndex = 0;
  ui.draftLine = null;
  showScreen("aufmass-edit");
}
function renderMeasureEdit() {
  const m = currentMeasure();
  if (!m) { showScreen("aufmass"); return; }
  $("ms-edit-title").textContent = m.name || m.title || "Aufmaß";
  $("ms-edit-sub").textContent = [m.address, m.phone, m.email].filter(Boolean).join(" · ") || "Keine Kontaktdaten";
  const photos = m.photos || [];
  if (!photos.length) {
    $("ms-canvas-wrap").innerHTML = `<div class="card muted">Foto aufnehmen oder aus der Galerie laden. Danach Maße als Pfeile einzeichnen.</div>`;
    $("ms-photo-nav").textContent = "0 Fotos";
    return;
  }
  if (ui.photoIndex >= photos.length) ui.photoIndex = photos.length - 1;
  $("ms-photo-nav").textContent = `${ui.photoIndex + 1} / ${photos.length}`;
  $("ms-canvas-wrap").innerHTML = `<canvas id="ms-canvas"></canvas>`;
  requestAnimationFrame(drawMeasureCanvas);
}
function addMeasurePhoto(file) {
  const m = currentMeasure();
  if (!m || !file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement("canvas");
      const max = 1400;
      let w = img.width, h = img.height;
      if (w > max) { h = h * (max / w); w = max; }
      c.width = w; c.height = h;
      c.getContext("2d").drawImage(img, 0, 0, w, h);
      m.photos = m.photos || [];
      m.photos.push({ src: c.toDataURL("image/jpeg", 0.82), arrows: [], notes: [] });
      ui.photoIndex = m.photos.length - 1;
      save();
      renderMeasureEdit();
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
}
function currentPhoto() {
  const m = currentMeasure();
  return m && m.photos ? m.photos[ui.photoIndex] : null;
}
function drawMeasureCanvas() {
  const canvas = $("ms-canvas");
  const photo = currentPhoto();
  if (!canvas || !photo) return;
  const img = new Image();
  img.onload = () => {
    const wrap = $("ms-canvas-wrap");
    const maxW = wrap.clientWidth || 390;
    const scale = maxW / img.width;
    canvas.width = img.width;
    canvas.height = img.height;
    canvas.style.width = maxW + "px";
    canvas.style.height = (img.height * scale) + "px";
    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0);
    ctx.strokeStyle = "#22d3ee";
    ctx.fillStyle = "#22d3ee";
    ctx.lineWidth = Math.max(3, img.width / 220);
    (photo.arrows || []).forEach(a => paintArrow(ctx, a, img.width));
    if (ui.draftLine) paintArrow(ctx, { ...ui.draftLine, label: "" }, img.width);
    (photo.notes || []).forEach(n => {
      ctx.font = `${Math.max(16, img.width / 28)}px sans-serif`;
      ctx.fillStyle = "#fde047";
      ctx.fillText(n.text, n.x, n.y);
    });
  };
  img.src = photo.src;
}
function paintArrow(ctx, a, w) {
  ctx.beginPath();
  ctx.moveTo(a.x1, a.y1);
  ctx.lineTo(a.x2, a.y2);
  ctx.stroke();
  const ang = Math.atan2(a.y2 - a.y1, a.x2 - a.x1);
  const head = Math.max(10, w / 40);
  ctx.beginPath();
  ctx.moveTo(a.x2, a.y2);
  ctx.lineTo(a.x2 - head * Math.cos(ang - 0.4), a.y2 - head * Math.sin(ang - 0.4));
  ctx.lineTo(a.x2 - head * Math.cos(ang + 0.4), a.y2 - head * Math.sin(ang + 0.4));
  ctx.closePath();
  ctx.fill();
  if (a.label) {
    ctx.font = `700 ${Math.max(18, w / 26)}px sans-serif`;
    ctx.fillStyle = "#fff";
    ctx.strokeStyle = "#082f49";
    ctx.lineWidth = 4;
    const mx = (a.x1 + a.x2) / 2, my = (a.y1 + a.y2) / 2 - 8;
    ctx.strokeText(a.label, mx, my);
    ctx.fillText(a.label, mx, my);
    ctx.strokeStyle = "#22d3ee";
    ctx.lineWidth = Math.max(3, w / 220);
    ctx.fillStyle = "#22d3ee";
  }
}
function canvasPoint(ev) {
  const canvas = $("ms-canvas");
  const r = canvas.getBoundingClientRect();
  const src = ev.touches ? ev.touches[0] : ev;
  return {
    x: (src.clientX - r.left) * (canvas.width / r.width),
    y: (src.clientY - r.top) * (canvas.height / r.height)
  };
}
function onCanvasDown(ev) {
  if (!$("ms-canvas") || !currentPhoto()) return;
  ev.preventDefault();
  const p = canvasPoint(ev);
  if (ui.drawMode === "note") {
    const sel = $("ms-note-select");
    let text = sel ? sel.value : "";
    if (text === "__custom") text = ($("ms-note-custom") && $("ms-note-custom").value.trim()) || "";
    if (!text) {
      alert("Bitte unten eine Notiz auswählen.");
      return;
    }
    currentPhoto().notes = currentPhoto().notes || [];
    currentPhoto().notes.push({ x: p.x, y: p.y, text });
    save();
    drawMeasureCanvas();
    return;
  }
  ui.draftLine = { x1: p.x, y1: p.y, x2: p.x, y2: p.y, label: "" };
}
function onCanvasMove(ev) {
  if (!ui.draftLine) return;
  ev.preventDefault();
  const p = canvasPoint(ev);
  ui.draftLine.x2 = p.x;
  ui.draftLine.y2 = p.y;
  drawMeasureCanvas();
}
function onCanvasUp() {
  if (!ui.draftLine || !currentPhoto()) return;
  const dx = ui.draftLine.x2 - ui.draftLine.x1;
  const dy = ui.draftLine.y2 - ui.draftLine.y1;
  if (Math.hypot(dx, dy) < 12) { ui.draftLine = null; drawMeasureCanvas(); return; }
  ui.pendingArrow = { ...ui.draftLine };
  ui.draftLine = null;
  $("ms-value").value = "";
  $("ms-unit").value = "cm";
  $("modal-measure-value").classList.add("show");
  drawMeasureCanvas();
}
function confirmMeasureValue() {
  if (!ui.pendingArrow || !currentPhoto()) {
    closeModal("modal-measure-value");
    return;
  }
  const raw = ($("ms-value").value || "").trim().replace(",", ".");
  const unit = $("ms-unit").value || "cm";
  if (!raw || Number.isNaN(Number(raw))) {
    alert("Bitte eine Zahl eingeben.");
    return;
  }
  const label = `${raw} ${unit}`;
  currentPhoto().arrows = currentPhoto().arrows || [];
  currentPhoto().arrows.push({ ...ui.pendingArrow, label, value: raw, unit });
  ui.pendingArrow = null;
  save();
  closeModal("modal-measure-value");
  drawMeasureCanvas();
}
function cancelMeasureValue() {
  ui.pendingArrow = null;
  closeModal("modal-measure-value");
  drawMeasureCanvas();
}
function undoMeasure() {
  const p = currentPhoto();
  if (!p) return;
  if (p.arrows && p.arrows.length) p.arrows.pop();
  else if (p.notes && p.notes.length) p.notes.pop();
  save();
  drawMeasureCanvas();
}
function shiftPhoto(dir) {
  const m = currentMeasure();
  if (!m || !m.photos.length) return;
  ui.photoIndex = (ui.photoIndex + dir + m.photos.length) % m.photos.length;
  renderMeasureEdit();
}
function deleteMeasure() {
  if (!confirm("Aufmaß-Projekt löschen?")) return;
  db.measures = db.measures.filter(m => m.id !== ui.measureId);
  save();
  showScreen("aufmass");
}

function renderSettings() {
  $("set-name").textContent = session.name;
  $("set-role").textContent = session.role === "admin" ? "Admin" : session.role === "verkaeufer" ? "Verkäufer" : "Monteur";
  $("admin-settings").classList.toggle("hidden", !can("arbeitszeiten"));
}

function closeModal(id) { $(id).classList.remove("show"); }
function escapeHtml(s) {
  return s.replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;" }[c]));
}

function login(role) {
  session = USERS[role];
  saveSession();
  $("login").classList.add("hidden");
  $("app").classList.remove("hidden");
  showScreen("start");
}
function logout() {
  session = null;
  localStorage.removeItem("workconnect.session");
  $("app").classList.add("hidden");
  $("login").classList.remove("hidden");
}

function boot() {
  if (session) {
    $("login").classList.add("hidden");
    $("app").classList.remove("hidden");
    showScreen("start");
  }
  setInterval(() => {
    if (ui.screen === "stempeluhr" && db.punchedIn) renderClock();
  }, 30000);
}

window.showScreen = showScreen;
window.toggleModule = toggleModule;
window.resetHome = resetHome;
window.saveHome = saveHome;
window.shiftCal = shiftCal;
window.setCalMode = setCalMode;
window.pickDay = pickDay;
window.openEventModal = openEventModal;
window.saveEvent = saveEvent;
window.deleteEvent = deleteEvent;
window.setFilter = setFilter;
window.cycleOrder = cycleOrder;
window.openOrderModal = openOrderModal;
window.saveOrder = saveOrder;
window.openPdf = openPdf;
window.openChat = openChat;
window.sendMsg = sendMsg;
window.cycleComp = cycleComp;
window.togglePunch = togglePunch;
window.toggleLoc = toggleLoc;
window.addLocation = addLocation;
window.closeModal = closeModal;
window.login = login;
window.logout = logout;
window.openMeasureModal = openMeasureModal;
window.saveMeasureProject = saveMeasureProject;
window.openMeasure = openMeasure;
window.addMeasurePhoto = addMeasurePhoto;
window.undoMeasure = undoMeasure;
window.shiftPhoto = shiftPhoto;
window.deleteMeasure = deleteMeasure;
window.confirmMeasureValue = confirmMeasureValue;
window.cancelMeasureValue = cancelMeasureValue;
window.setDrawMode = function(mode) {
  ui.drawMode = mode;
  const a = $("mode-arrow"), n = $("mode-note");
  if (a) a.classList.toggle("on", mode === "arrow");
  if (n) n.classList.toggle("on", mode === "note");
};
window.renderOrders = renderOrders;
window.renderContacts = renderContacts;
window.renderChats = renderChats;

document.addEventListener("pointerdown", ev => { if (ev.target && ev.target.id === "ms-canvas") onCanvasDown(ev); });
document.addEventListener("pointermove", ev => { if (ui.draftLine) onCanvasMove(ev); });
document.addEventListener("pointerup", ev => { if (ui.draftLine) onCanvasUp(ev); });
document.addEventListener("DOMContentLoaded", boot);
